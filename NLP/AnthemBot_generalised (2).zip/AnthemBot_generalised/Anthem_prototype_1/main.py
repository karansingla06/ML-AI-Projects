# libraries to be used
from flask import Flask, render_template, flash, request
from wtforms import Form, TextField, validators

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from string import punctuation
#import pandas as pd
from nltk.stem.snowball import SnowballStemmer
stemmer = SnowballStemmer("english")
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()


### EOC doc parsing
#import mammoth
#with open(r"C:\Users\user\Desktop\Anthem1.docx", "rb") as docx_file:
#    result = mammoth.convert_to_html(docx_file)
#    html = result.value # The generated HTML
#    messages = result.messages

### File Parsing
f = open(r"C:\Users\user\Desktop\AnthemBot_generalised\Anthem_prototype_1\Anthem1.html","r")
html=f.read()

#creating a global BeautifulSoup object
from bs4 import BeautifulSoup
soup = BeautifulSoup(html,'html.parser')
blacklist = ["img"]
for tag in soup.findAll():
        if tag.name.lower() in blacklist:
            # blacklisted tags are removed in their entirety
            tag.extract()


# App config.
DEBUG = True
app = Flask(__name__,static_url_path='/static')
app.config.from_object(__name__)
app.config['SECRET_KEY'] = '7d441f27d441f27567d441f2b6176a'
 


# return Tokenized and stemmed words list from user input which were present in bag of words
def tokenize_user_input(user_input,new_bag):
#    sents = sent_tokenize(user_input)
    word_sent = word_tokenize(user_input.lower())
    _stopwords = set(stopwords.words('english') + list(punctuation))
    user_input_words=[word for word in word_sent if word not in _stopwords]
    user_input_words=[stemmer.stem(i) for i in user_input_words]
    user_input_words=[i for i in user_input_words if (i in new_bag and i not in ('copay','coinsur','health','claim','want','know','cover','elig','insur','plan'))]
    return user_input_words



# return the key sections where important words were occuring
def key_section(user_input_words,d_stem):
    key_sec={}
    for i in user_input_words:
        temp=[]
        for key,val in d_stem.items():
             if i in val:
                 temp.append(key)
        key_sec[i]=set(temp)
    return key_sec



# return the dictionary having main section as key and its content as value
def get_main_section_dic(soup):
    d_h1={}
    all_h1=soup.find_all('h1')
    for h1 in all_h1:
        first=h1
        second=first.find_next('h1')
        temp=""
    
        while first.findNext()!=second:
            if str(first.findNext().text) != "":
                temp+= str(first.findNext())+" "
            first=first.findNext() 
        temp=temp.replace('.'," . ")
        temp=temp.replace('('," ( ")
        temp=temp.replace(')'," ) ")
        temp=temp.replace('<'," <")
        temp=temp.replace('>',"> ")
        d_h1[str(h1.text).strip()]=temp
    d_h1.pop('Section 4. Table of Contents')
    d_h1.pop('Section 1. Schedule of Benefits (Who Pays What)')
    return d_h1



#return the dictionary of dictionary containg main sections and subsections and its data
def get_subsection_dic(d_h1):
    d_h2={}
    for h1,h1_val in d_h1.items():
        d_unio={}
        soup2 = BeautifulSoup(h1_val,'html.parser')
        all_h2=soup2.find_all('h2')
        if len(all_h2)!=0 :
            for h2 in all_h2:
                first=h2
                second=first.find_next('h2')
                temp=""
            
                while first.findNext()!=second:
                    if str(first.findNext().text) != "":
                        temp+= str(first.findNext())+" "
                    first=first.findNext() 
                d_unio[h2.text]=temp
            d_h2[str(h1).strip()]=d_unio
        else:
            d_h2[str(h1).strip()]={str(h1):h1_val}
    return d_h2



#return all the importanct keywords after in the EOC document after stopwords removal
def get_kwds(d_h2):
    d_kwds={}
    for key,val in d_h2.items():
        for key2,val2 in val.items():
            if val2 is not None:
                word_sent = word_tokenize(val2.lower())
                _stopwords = set(stopwords.words('english') + list(punctuation)+['·',
          '’',
          '“',
          '”'])
                section_words=[word for word in word_sent if word not in _stopwords]
                d_kwds[key2]=list(word for word in set(section_words) if (word.isalpha() and len(word)>2 and len(set(word))!=1))
    return d_kwds



# return all the stemmed keywords 
def get_stem(d_kwds):
    d_stem={}
    for key,val in d_kwds.items():
        singles = [stemmer.stem(i) for i in val]
        temp=set(singles)
        d_stem[key]=list(temp)
    return d_stem



# return a list with all important words
def get_bag_of_words(d_stem):
    bag_of_words2=[]
    for i,j in d_stem.items():
        bag_of_words2.append(j)
    new_bag=[]
    for list_word in bag_of_words2:
        for i in list_word:
            if i.isalpha():
                new_bag.append(i) 
    new_bag=list(set(new_bag))
    return new_bag



# return a string with the benefits section data
def find_benefit_data(lis,kwds,d_h2):
    res=""
    for i in lis:
        res+="<h3>"+i+"</h3>"
        for key,val in d_h2.items():
            for key2,val2 in val.items():
                if i==key2:
                    soup4= BeautifulSoup(val2,'html.parser')
                    ps=soup4.find_all('p')
                    for p1 in ps:
                        checklist=str(p1).lower().split()
                        checklist=[stemmer.stem(y) for y in checklist]
                        if all(x in checklist for x in kwds):
                            res+=p1.prettify()
#                
                    #    else:
                     #       if any(x in checklist for x in kwds):
                      #          res+=p1.prettify()
       
                        
    return res



# return the final string having the response to be given to the user
def final_output_data(key_section,user_input_words,d_h2):
    final_cmn_section=[]
    final_output=""
    table_content=""
    section_content=""
    if len(key_section.keys())!=0:    
            final_cmn_section= list(set.intersection(*map(set,key_section.values())))
            section_content+=find_benefit_data(final_cmn_section,user_input_words,d_h2)   
            soupTable= BeautifulSoup(html,'html.parser')
            #taking all the table rows present in EOC
            trows = soupTable.find_all('tr')
            
            if len(final_cmn_section)==0:
                final_output+="Sorry, I could'nt find the relevant data. Could you please try again."
                
            else:
                for i in final_cmn_section:
                    temp=i.split()
                    if len(temp)>=3:
                        temp=" ".join(temp[0:3])
                    else:
                        temp=i
                    
                    for tr in trows:
                        if "See" in tr.text and temp.strip() in tr.text:
                            continue
                        elif temp.strip() in tr.text and ("Coinsurance" in tr.text or "Copayment" in tr.text):
                            table_content+="<br><h4>"+"Coinsurance/Copayment details of : "+i.strip()+"</h4>"
                            section_tr=tr
                            table_content+=section_tr.prettify()
                        elif (temp.strip() in tr.text and len(table_content)==0):
                            table_content+="<br><h4>"+"Coinsurance/Copayment details of : "+i.strip()+"</h4>"
                            section_tr=tr
                            table_content+=section_tr.prettify()
                final_output=section_content+table_content
                            
    else:
        final_output+="Sorry, I could'nt find the relevant data. Could you please try again."
    return final_output
    



# submit form for UI
class ReusableForm(Form):
    name = TextField('Query:', validators=[validators.required()])

# flask  
@app.route("/", methods=['GET', 'POST'])
def startup():
    form = ReusableForm(request.form)
    print(form.errors)
    if request.method == 'POST':
        #query = request.form['name']
        final_output=""
        query=request.form['name']
        s_words=tokenize_user_input(query,bog)
        key_sec=key_section(s_words,stem)
        l_words=[lemmatizer.lemmatize(i) for i in s_words]
        final_output=final_output_data(key_sec,l_words,d_h2)
        
        if form.validate():
            output = final_output	
            flash(query)
            flash(output)			
        else:
            flash('')
            flash('Please enter a query.')  
    return render_template('anthem_poc_template.html', form=ReusableForm())
 
    
# global initialization
d_h1=get_main_section_dic(soup)
d_h2=get_subsection_dic(d_h1)
kwds=get_kwds(d_h2)
stem=get_stem(kwds)
bog=get_bag_of_words(stem)
    


if __name__ == "__main__":
    app.run()
    
